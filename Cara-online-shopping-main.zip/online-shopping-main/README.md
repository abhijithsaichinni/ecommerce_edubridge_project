# Cara-online-shopping(Ecommerce Website)

1. Introduction

 - This is a sample 🛒e-commerce website built using HTML, CSS, and JavaScript. The website is designed to showcase the   various features of an e-commerce website, including product listings, shopping carts, and login pages.
 
2. Key Sections Covered
 - Modern CSS, including flexbox and CSS Grid for layout.<br>
 - Multipage Ecommerce Website Project with Signin & Singup page.<br>
 - Use common components and layout patterns for professional 🌐website design and development.<br>
 - Build amazing👍 professional and responsive websites.<br>
 - Advanced responsive design using media queries & Many More.<br>
<br>

3 . Screenshots
#  Desktop Screen <br>

- Home page<br>
![Home page for pc](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/31fab2f8-4f81-4f3a-b291-0a1e13d579b3)
<br>

![2](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/abf0d24d-cd3a-426a-a710-e635047344bd)
 <br>
 
 ![footer](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/bb2a979d-b70e-448e-8349-9fee46b7c904)
 <br>
![login](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/48b3363d-dcb6-4d18-800f-45a2bf79e856)
<br>
 # Phone Screen <br>
 
![phone](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/db2a8975-73ce-4445-a508-f3fc1ed959dd) 
<br>
![phone2](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/a3573313-d037-45f9-9afb-decfdf065621)
<br>

![phone3](https://github.com/Rahul02M/Cara-online-shopping/assets/133855195/a6561b92-e7e4-4b60-b1ea-99ef632a7c20)
